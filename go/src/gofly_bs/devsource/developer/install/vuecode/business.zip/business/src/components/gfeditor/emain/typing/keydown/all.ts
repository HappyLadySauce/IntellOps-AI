import Default from './default';

class All extends Default {
	hotkey = 'mod+a';
}
export default All;
