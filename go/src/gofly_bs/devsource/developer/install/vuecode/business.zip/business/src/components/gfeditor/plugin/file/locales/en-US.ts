export default {
	file: {
		errorMessageCopy: 'Copy error message',
		loadError: 'The file failed to load!',
		uploadError: 'The picture failed to upload!',
		uploadLimitError: 'Upload file size is limited to $size',
		download: 'Download',
		preview: 'Preview',
	},
};
