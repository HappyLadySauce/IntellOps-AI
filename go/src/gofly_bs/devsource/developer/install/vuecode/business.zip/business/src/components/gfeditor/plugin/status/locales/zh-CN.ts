export default {
	status: {
		defaultValue: '设置状态',
	},
};
