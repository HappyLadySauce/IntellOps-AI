import { useUserStore } from '@/store'
import { isAllUrl } from '@/utils/is';
import { useClipboard } from '@vueuse/core';
import { Message } from '@arco-design/web-vue';
//获取附件完整访问路径
export function GetFullPath(url:any):string{
    if(!url){
        return ""
    }else if(isAllUrl(url)){
        return url
    }else{
        const userStore = useUserStore()
         if(url.startsWith("resource/uploads/")){//本地访问域名
            return userStore.localurl+url
         }else{//获取设置访问域名
            return userStore.rooturl+url
         }
    }
}
//复制
var copyObj :any
export function CopyText(text:any,msg:string){
    if(!copyObj){
        const { copy } = useClipboard();
        copyObj=copy
    }
    copyObj(text);
    Message.success({content:msg,id:"copy"});
}
