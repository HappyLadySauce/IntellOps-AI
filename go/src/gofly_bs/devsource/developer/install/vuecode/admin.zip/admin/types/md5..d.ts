declare module 'md5' {
    const content: any
    export = content
  }