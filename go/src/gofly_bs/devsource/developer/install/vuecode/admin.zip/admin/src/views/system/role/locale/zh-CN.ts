export default {
  'system.role': '角色管理',
  // columns

};
