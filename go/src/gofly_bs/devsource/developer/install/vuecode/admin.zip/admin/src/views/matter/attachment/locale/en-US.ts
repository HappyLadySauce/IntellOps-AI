export default {
  'system.dept': 'Department',
};
