export default {
  'store.article.title': 'article',
};
