export default {
  'business.rootname': 'Business',
  'business.bizuser.title': 'account',
};
