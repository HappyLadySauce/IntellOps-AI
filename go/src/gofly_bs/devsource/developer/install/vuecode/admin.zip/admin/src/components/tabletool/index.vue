<template>
  <a-space>
  <a-button v-permission="'add'" type="primary" @click="handleCreate" v-if="inArray(showbtn,'create')">
    <template #icon>
      <icon-plus />
    </template>
    {{ $t('searchTable.operation.create') }} 
  </a-button>
  <slot></slot>
  <a-tooltip :content="$t('searchTable.actions.refresh')" v-if="inArray(showbtn,'refresh')">
    <a-button class="gf_hover_btn-border" @click="refresh" >
      <template #icon><icon-refresh /></template>
    </a-button>
  </a-tooltip>
  <a-dropdown @select="handleSelectDensity" v-if="inArray(showbtn,'selectdensity')">
    <a-tooltip :content="$t('searchTable.actions.density')">
      <a-button class="gf_hover_btn-border" >
        <template #icon><icon-line-height size="18" /></template>
      </a-button>
    </a-tooltip>
    <template #content>
      <a-doption
        v-for="item in densityList"
        :key="item.value"
        :value="item.value"
        :class="{ active: item.value === size }"
      >
        <span>{{ item.name }}</span>
      </a-doption>
    </template>
  </a-dropdown>
  <a-tooltip :content="isFullscreen?'退出':'全屏'" v-if="inArray(showbtn,'fullscreen')">
    <a-button class="gf_hover_btn-border" @click="handleFullscreen" >
      <template #icon>
        <icon-fullscreen v-if="!isFullscreen" />
        <icon-fullscreen-exit v-else />
      </template>
    </a-button>
  </a-tooltip>
</a-space>
</template>

<script lang="ts" setup>
  import { ref, computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { SizeProps } from './data';
  import { inArray } from '@/utils/is';
  const { t } = useI18n();
  const props = defineProps({
    showbtn: {
      type:  Array,
      required: true
    },
  })
  const emits = defineEmits(['create','refresh','selectdensity','fullscreen'])
  const isFullscreen = ref(false);
  const size = ref<SizeProps>('large');
  const densityList = computed(() => [
    {
      name: t('searchTable.size.mini'),
      value: 'mini',
    },
    {
      name: t('searchTable.size.small'),
      value: 'small',
    },
    {
      name: t('searchTable.size.medium'),
      value: 'medium',
    },
    {
      name: t('searchTable.size.large'),
      value: 'large',
    },
  ]);
  const handleCreate=()=>{
    emits("create")
  }
  const refresh=()=>{
    emits("refresh")
  }
  //列表密度
  const handleSelectDensity = (
    val: string | number | Record<string, any> | undefined,
    e: Event
  ) => {
    size.value = val as SizeProps;
    emits("selectdensity",size.value)
  };
  const handleFullscreen=()=>{
    isFullscreen.value = !isFullscreen.value
    emits("fullscreen",isFullscreen.value)
  }
</script>

<style scoped lang="less">
</style>
