export default {
  'menu.system.rule': 'Rule',
};
